package com.EmloyeeDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.Employee.Model.Employee;

public class EmployeeDAO {
    private Connection conn;

    // Database configuration
    private static final String DB_URL = "jdbc:mysql://localhost:3307/employee";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Test";

    // SQL queries
    private static final String SELECT_ALL_EMPLOYEES = "SELECT * FROM Employee";
    private static final String INSERT_EMPLOYEE = "INSERT INTO Employee (name, address, gender, salary, birthdate) VALUES (?, ?, ?, ?, ?)";
    private static final String UPDATE_EMPLOYEE = "UPDATE Employee SET name = ?, address = ?, gender = ?, salary = ?, birthdate = ? WHERE employeeId = ?";
    private static final String DELETE_EMPLOYEE_BY_ID = "DELETE FROM Employee WHERE employeeId = ?";
    private static final String SELECT_EMPLOYEES_BY_PAGE = "SELECT * FROM Employee LIMIT ? OFFSET ?";
    private static final String SELECT_TOTAL_RECORDS = "SELECT COUNT(*) FROM Employee";

    public EmployeeDAO() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public void closeConnection() {
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Employee> getAllEmployees() {
        List<Employee> employees = new ArrayList<>();
        try {
            PreparedStatement ps = conn.prepareStatement(SELECT_ALL_EMPLOYEES);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Employee employee = new Employee();
                employee.setEmployeeId(rs.getInt("employeeId"));
                employee.setName(rs.getString("name"));
                employee.setAddress(rs.getString("address"));
                employee.setGender(rs.getInt("gender"));
                employee.setSalary(rs.getDouble("salary"));
                employee.setBirthdate(rs.getDate("birthdate"));
                employees.add(employee);
            }
            rs.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return employees;
    }

    public void insertEmployee(Employee employee) {
        try {
            PreparedStatement ps = conn.prepareStatement(INSERT_EMPLOYEE);
            ps.setString(1, employee.getName());
            ps.setString(2, employee.getAddress());
            ps.setInt(3, employee.getGender());
            ps.setDouble(4, employee.getSalary());
            ps.setDate(5, new java.sql.Date(employee.getBirthdate().getTime()));
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateEmployee(Employee employee) {
        try {
            PreparedStatement ps = conn.prepareStatement(UPDATE_EMPLOYEE);
            ps.setString(1, employee.getName());
            ps.setString(2, employee.getAddress());
            ps.setInt(3, employee.getGender());
            ps.setDouble(4, employee.getSalary());
            ps.setDate(5, new java.sql.Date(employee.getBirthdate().getTime()));
            ps.setInt(6, employee.getEmployeeId());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteEmployeeById(int employeeId) {
        try {
            PreparedStatement ps = conn.prepareStatement(DELETE_EMPLOYEE_BY_ID);
            ps.setInt(1, employeeId);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Employee> getEmployeesByPage(int currentPage, int recordsPerPage) {
        List<Employee> employees = new ArrayList<>();
        try {
            int offset = (currentPage - 1) * recordsPerPage;
            PreparedStatement ps = conn.prepareStatement(SELECT_EMPLOYEES_BY_PAGE);
            ps.setInt(1, recordsPerPage);
            ps.setInt(2, offset);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Employee employee = new Employee();
                employee.setEmployeeId(rs.getInt("employeeId"));
                employee.setName(rs.getString("name"));
                employee.setAddress(rs.getString("address"));
                employee.setGender(rs.getInt("gender"));
                employee.setSalary(rs.getDouble("salary"));
                employee.setBirthdate(rs.getDate("birthdate"));
                employees.add(employee);
            }
            rs.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return employees;
    }

    public int getTotalRecords() {
        int totalRecords = 0;
        try {
            PreparedStatement ps = conn.prepareStatement(SELECT_TOTAL_RECORDS);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                totalRecords = rs.getInt(1);
            }
            rs.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return totalRecords;
    }

    // Other methods can be added here based on requirements.

}
