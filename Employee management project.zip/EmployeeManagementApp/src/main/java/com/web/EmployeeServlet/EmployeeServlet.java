package com.web.EmployeeServlet;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.EmloyeeDAO.EmployeeDAO;
import com.Employee.Model.Employee;

@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private EmployeeDAO employeeDAO;

    public EmployeeServlet() {
        super();
        employeeDAO = new EmployeeDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action != null && !action.isEmpty()) {
            switch (action) {
                case "insert":
                    insertEmployee(request, response);
                    break;
                case "update":
                    updateEmployee(request, response);
                    break;
                case "delete":
                    deleteEmployee(request, response);
                    break;
                default:
                    break;
            }
        } else {
            showEmployeeList(request, response);
        }
    }

    private void showEmployeeList(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int recordsPerPage = 5;
        int currentPage = 1;
        if (request.getParameter("page") != null) {
            currentPage = Integer.parseInt(request.getParameter("page"));
        }

        List<Employee> employeeList = employeeDAO.getEmployeesByPage(currentPage, recordsPerPage);
        int totalRecords = employeeDAO.getTotalRecords();
        int pageCount = (int) Math.ceil((double) totalRecords / recordsPerPage);

        request.setAttribute("employeeList", employeeList);
        request.setAttribute("pageCount", pageCount);
        request.setAttribute("currentPage", currentPage);
        request.getRequestDispatcher("listEmployee.jsp").forward(request, response);
    }

    private void insertEmployee(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String address = request.getParameter("address");
        int gender = Integer.parseInt(request.getParameter("gender"));
        double salary = Double.parseDouble(request.getParameter("salary"));
        Date birthdate = parseDate(request.getParameter("birthdate"));

        Employee employee = new Employee(0, name, address, gender, salary, birthdate);
        employeeDAO.insertEmployee(employee);

        response.sendRedirect("EmployeeServlet");
    }

    private void updateEmployee(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int employeeId = Integer.parseInt(request.getParameter("employeeId"));
        String name = request.getParameter("name");
        String address = request.getParameter("address");
        int gender = Integer.parseInt(request.getParameter("gender"));
        double salary = Double.parseDouble(request.getParameter("salary"));
        Date birthdate = parseDate(request.getParameter("birthdate"));

        Employee employee = new Employee(employeeId, name, address, gender, salary, birthdate);
        employeeDAO.updateEmployee(employee);

        response.sendRedirect("EmployeeServlet");
    }

    private void deleteEmployee(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String employeeIdStr = request.getParameter("employeeId");
        
        if (employeeIdStr != null && !employeeIdStr.isEmpty()) {
            try {
                int employeeId = Integer.parseInt(employeeIdStr);
                employeeDAO.deleteEmployeeById(employeeId);
            } catch (NumberFormatException e) {
                e.printStackTrace();
                // Handle invalid employee ID input here (e.g., show an error message)
            }
        } else {
            // Handle empty employee ID input here (e.g., show an error message)
        }

        response.sendRedirect("EmployeeServlet");
    }

    private Date parseDate(String dateString) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        try {
            return format.parse(dateString);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
}
