package com.Employee.Model;
import java.util.Date;

public class Employee {
    private int employeeId;
    private String name;
    private String address;
    private int gender;
    private double salary;
    private Date birthdate;

    
    public static final int GENDER_FEMALE = 0;
    public static final int GENDER_MALE = 1;
    public static final int GENDER_OTHER = 2;

    // Default constructor
    public Employee() {
        gender = -1; // Default value for gender
    }

    // Parameterized constructor
    public Employee(int employeeId, String name, String address, int gender, double salary, Date birthdate) {
        this.employeeId = employeeId;
        this.name = name;
        this.address = address;
        this.gender = gender;
        this.salary = salary;
        this.birthdate = birthdate;
    }

    // Getters and setters
    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public Date getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(Date birthdate) {
        this.birthdate = birthdate;
    }

    @Override
    public String toString() {
        return "Employee [employeeId=" + employeeId + ", name=" + name + ", address=" + address + ", gender=" + gender
                + ", salary=" + salary + ", birthdate=" + birthdate + "]";
    }
}
